import React, { useState } from "react";
import ASLCamera from "./components/ASLCamera";

function App() {
  const [translation, setTranslation] = useState("");

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold mb-6">ASL Translator</h1>
      <ASLCamera onTranslate={setTranslation} />
      <div className="mt-4 text-xl">{translation}</div>
    </div>
  );
}

export default App;