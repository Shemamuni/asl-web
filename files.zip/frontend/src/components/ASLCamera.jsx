import React, { useRef, useEffect } from "react";

const ASLCamera = ({ onTranslate }) => {
  const videoRef = useRef();

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true })
      .then((stream) => {
        videoRef.current.srcObject = stream;
      });
  }, []);

  // Placeholder for translation logic
  const translateASL = () => {
    if (onTranslate) onTranslate("Translation result...");
  };

  return (
    <div>
      <video ref={videoRef} autoPlay style={{ width: "320px", height: "240px" }} />
      <button onClick={translateASL}>Translate</button>
    </div>
  );
};

export default ASLCamera;