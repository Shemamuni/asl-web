# ASL Web App

A web application for real-time American Sign Language (ASL) translation and interactive learning.

## Features

- **Real-Time ASL Translation:** Use your webcam to recognize hand signs and translate to text/speech.
- **Text-to-ASL:** Convert typed text to animated ASL avatars or video.
- **Interactive Learning:** Quizzes and flashcards for ASL practice.
- **Accessibility:** Keyboard navigation, screen reader support, and more.

## Tech Stack

- **Frontend:** React.js, Tailwind CSS, MediaPipe Hands, TensorFlow.js
- **Backend:** Serverless (AWS Lambda or GCF), Firebase/PostgreSQL (optional)
- **Hosting:** Vercel or Netlify (frontend), AWS/GCF (backend)

## Getting Started

```bash
cd frontend
npm install
npm start
```

## Next Steps

- Integrate MediaPipe Hands for gesture detection.
- Train and convert an ASL model to TensorFlow.js.
- Implement backend APIs for translation and user data.
